

from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
#import the model
import os
import csv



def Mises_Displacement(odb_path,save_mises,save_displacement):
    max_mises = 0
    max_s11 = 0
    max_s22 = 0
    headers = ['label', 'mise', 's11','s22']
    odb = openOdb(odb_path, readOnly=False)
    # Create a txt document to store the obtained stress
    with open(save_mises, "w") as fp:
        writer = csv.writer(fp)
        writer.writerow(headers)
        # elemsets = self.odb.rootAssembly.instances['PART-1-1'].nodeSets["SET-1"]
        mises = odb.steps["Step-1"].frames[-1].fieldOutputs['S']

        # elementSet = self.odb.rootAssembly.elementSets[set]
        elementSet = odb.rootAssembly.instances['CASING-1'].elementSets['ELEM_SET']
        mises_ = mises.getSubset(region=elementSet)

        # print(mise.values)
        for value in mises_.values:
            # print("elemlabel:",value.elementLabel," mise:",value.mises,"\n")
            writer.writerow((str(value.elementLabel), str(value.mises), str(value.data[0]), str(value.data[1])))
            # fp.write("elemlabel:"+str(value.elementLabel)+"  mise:"+str(value.mises)+"\n")
            if value.mises > max_mises:
                max_mises = value.mises
            # print(value.data)
            if value.data[0] > max_s11:
                max_s11 = value.data[0]
            if value.data[1] > max_s22:
                max_s22 = value.data[1]
        writer.writerow((str("max_mises:"), str(max_mises)))
        writer.writerow((str("max_s11:"), str(max_s11)))
        writer.writerow((str("max_s22:"), str(max_s22)))

    # Displacement
    max_displacement = 0
    headers = ['Position', 'Type', 'label', 'X displacement', 'Y displacement', 'magnitude']

    with open(save_displacement, "w") as fp:
        writer = csv.writer(fp)
        writer.writerow(headers)

        displacement = odb.steps['Step-1'].frames[-1].fieldOutputs['U']
        nodeSet = odb.rootAssembly.instances['CASING-1'].nodeSets['NODE_SET']

        displacement_ = displacement.getSubset(region=nodeSet)
        for displacement_value in displacement_.values:
            writer.writerow((str(displacement_value.position), str(displacement_value.type),
                             str(displacement_value.nodeLabel), str(displacement_value.data[0]),
                             str(displacement_value.data[1]), str(displacement_value.magnitude)))
            if displacement_value.magnitude > max_displacement:
                max_displacement = displacement_value.magnitude
        writer.writerow((str("max_displacement:"), str(max_displacement)))
    odb.close()




if __name__ == '__main__':

    odbs = os.listdir("C:/Users/ChuiJiang Kong/Desktop/odbs")
    for item in odbs:
        odb_path = "C:/Users/ChuiJiang Kong/Desktop/odbs/"+item

        Mises_Displacement(odb_path=odb_path,save_mises=item.split(".")[0]+"_Mises_out.csv",save_displacement=item.split(".")[0]+"_Displacement_out.csv")

